'use strict';
(() => {
    const api = acquireVsCodeApi();
    const $ = id => document.getElementById(id);
    const copy = value => JSON.parse(JSON.stringify(value));
    const persisted = api.getState() || {};
    let model, draft, group = 'Редактор', pending = false, autoTimer, toastTimer;
    $('autoApply').checked = !!persisted.autoApply;
    function persist() { api.setState({ draft, autoApply: $('autoApply').checked }); }
    function notify(message, error = false) {
        $('toast').textContent = message; $('toast').classList.toggle('error', error); $('toast').hidden = false;
        clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true; }, error ? 7000 : 3500);
    }
    function signature(value) { return JSON.stringify([value.base, value.colors, value.syntax, value.settings, value.background]); }
    function isInvalid() { return !!document.querySelector('[aria-invalid="true"]'); }
    function status() {
        if (!draft) return;
        const applied = model.applied && signature(model.current) === signature(draft);
        $('draftName').textContent = draft.name;
        $('status').textContent = pending ? 'Применяем настройки…' : isInvalid() ? 'Проверь введённый цвет' : applied ? 'Применено к профилю VS Code' : 'Есть изменения в предпросмотре';
        $('apply').disabled = pending || isInvalid();
        $('apply').firstChild.textContent = pending ? 'Применяем… ' : 'Применить ';
        $('reset').disabled = pending || !model.canReset;
    }
    function send(type, extra = {}) {
        if (!model) return;
        pending = true; status();
        api.postMessage({ type, ...extra });
    }
    function changed() {
        preview(); persist(); status();
        clearTimeout(autoTimer);
        if ($('autoApply').checked && !isInvalid()) autoTimer = setTimeout(() => send('apply', { profile: copy(draft) }), 650);
    }
    function contrast(a, b) {
        const light = hex => {
            const rgb = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255).map(v => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
            return rgb[0] * 0.2126 + rgb[1] * 0.7152 + rgb[2] * 0.0722;
        };
        const values = [light(a), light(b)].sort((x, y) => y - x);
        return (values[0] + 0.05) / (values[1] + 0.05);
    }
    function preview() {
        const c = draft.colors, box = $('preview');
        const vars = {
            bg: 'editor.background', fg: 'editor.foreground', side: 'sideBar.background', 'side-fg': 'sideBar.foreground',
            title: 'titleBar.activeBackground', 'title-fg': 'titleBar.activeForeground', activity: 'activityBar.background',
            'activity-fg': 'activityBar.foreground', inactive: 'tab.inactiveBackground', tab: 'tab.activeBackground',
            'tab-fg': 'tab.activeForeground', accent: 'focusBorder', border: 'editorGroup.border',
            highlight: 'editor.lineHighlightBackground', selection: 'editor.selectionBackground', cursor: 'editorCursor.foreground',
            muted: 'editorLineNumber.foreground', status: 'statusBar.background', 'status-fg': 'statusBar.foreground'
        };
        for (const [name, key] of Object.entries(vars)) box.style.setProperty('--p-' + name, c[key]);
        for (const [name, value] of Object.entries(draft.syntax)) box.style.setProperty('--s-' + name, value);
        const code = $('previewCode'), s = draft.settings;
        code.style.fontFamily = s['editor.fontFamily'];
        code.style.fontSize = Math.max(10, Math.min(18, s['editor.fontSize'])) + 'px';
        code.style.lineHeight = Math.max(16, Math.min(30, s['editor.lineHeight'])) + 'px';
        code.style.fontWeight = s['editor.fontWeight']; code.style.letterSpacing = s['editor.letterSpacing'] + 'px';
        code.style.fontVariantLigatures = s['editor.fontLigatures'] ? 'normal' : 'none';
        $('previewName').textContent = draft.name;
        const ratio = contrast(c['editor.background'], c['editor.foreground']);
        $('contrastHint').textContent = `Контраст текста и фона: ${ratio.toFixed(1)}:1. ${ratio < 4.5 ? 'Для мелкого текста лучше выбрать более контрастные оттенки.' : 'Текст хорошо отличается от фона.'}`;
        $('contrastHint').classList.toggle('warning', ratio < 4.5);
        const bg = draft.background;
        $('wallpaper').style.backgroundImage = bg.image ? `url("${bg.image}")` : 'none';
        $('wallpaper').style.opacity = bg.opacity; $('wallpaper').style.filter = `blur(${bg.blur}px)`;
        $('wallpaper').style.backgroundSize = bg.fit; $('wallpaper').style.backgroundPosition = bg.position;
        $('imageLabel').textContent = bg.image ? 'Твой фон загружен' : 'Добавь атмосферу';
        $('removeImage').hidden = !bg.image;
        $('opacityOut').textContent = Math.round(bg.opacity * 100) + '%'; $('blurOut').textContent = bg.blur + ' px';
        document.querySelectorAll('.preset-card').forEach(button => button.classList.toggle('selected', button.dataset.id === draft.id));
    }
    function swatch(color) { const dot = document.createElement('i'); dot.style.background = color; return dot; }
    function palettes() {
        $('presetGrid').replaceChildren();
        for (const preset of model.presets) {
            const button = document.createElement('button'); button.className = 'preset-card'; button.dataset.id = preset.id;
            button.setAttribute('aria-label', preset.name + ': ' + preset.subtitle);
            const colors = document.createElement('span'); colors.className = 'swatches';
            [preset.colors['editor.background'], preset.colors.focusBorder, preset.syntax.strings, preset.syntax.keywords].forEach(color => colors.append(swatch(color)));
            const name = document.createElement('strong'); name.textContent = preset.name;
            const info = document.createElement('small'); info.textContent = preset.subtitle;
            button.append(colors, name, info); button.addEventListener('click', () => choose(preset)); $('presetGrid').append(button);
        }
    }
    function choose(profile) { draft = copy(profile); renderFields(); changed(); }
    function colorControls() {
        $('colorGrid').replaceChildren();
        const syntax = group === 'Синтаксис', values = syntax ? draft.syntax : draft.colors;
        const fields = syntax ? model.syntaxFields : model.colorFields.filter(field => field[2] === group);
        for (const [key, title] of fields) {
            const row = document.createElement('div'); row.className = 'color-row';
            const picker = document.createElement('input'); picker.type = 'color'; picker.value = values[key]; picker.setAttribute('aria-label', title);
            const label = document.createElement('span'); label.className = 'color-label'; label.textContent = title;
            const text = document.createElement('input'); text.className = 'hex-input'; text.value = values[key]; text.maxLength = 7; text.spellcheck = false; text.setAttribute('aria-label', title + ', HEX');
            picker.addEventListener('input', () => { values[key] = picker.value.toUpperCase(); text.value = values[key]; text.removeAttribute('aria-invalid'); changed(); });
            text.addEventListener('input', () => {
                const good = /^#[0-9a-f]{6}$/i.test(text.value); text.setAttribute('aria-invalid', String(!good));
                if (good) { values[key] = text.value.toUpperCase(); picker.value = values[key]; changed(); } else status();
            });
            row.append(picker, label, text); $('colorGrid').append(row);
        }
    }
    const labels = { on: 'Включено', off: 'Выключено', left: 'Слева', right: 'Справа', multiple: 'Все вкладки', single: 'Одна вкладка', none: 'Скрыть', default: 'По умолчанию', top: 'Сверху', bottom: 'Снизу', hidden: 'Скрыть', relative: 'Относительные', interval: 'Через 10 строк', selection: 'В выделении', boundary: 'На границах', trailing: 'В конце строк', all: 'Все', solid: 'Без мигания', blink: 'Обычное', smooth: 'Плавное', phase: 'Затухание', expand: 'Расширение', line: 'Линия', block: 'Блок', underline: 'Подчёркивание', 'line-thin': 'Тонкая линия', 'block-outline': 'Контур блока', 'underline-thin': 'Тонкое подчёркивание', wordWrapColumn: 'По ширине колонки', bounded: 'По границе окна' };
    function editorControls() {
        $('editorGrid').replaceChildren();
        for (const [key, title, kind, , min, max, step] of model.settingFields) {
            const label = document.createElement('label'); label.className = kind === 'boolean' ? 'toggle-field' : 'field';
            const titleElement = document.createElement('span'); titleElement.textContent = title;
            let input;
            if (kind === 'select') {
                input = document.createElement('select');
                for (const value of min) { const option = document.createElement('option'); option.value = value; option.textContent = labels[value] || value; input.append(option); }
            } else {
                input = document.createElement('input'); input.type = kind === 'boolean' ? 'checkbox' : kind === 'number' ? 'range' : 'text';
                if (kind === 'number') { input.min = min; input.max = max; input.step = step; }
                if (kind === 'text') { input.maxLength = 200; input.spellcheck = false; }
            }
            if (kind === 'boolean') input.checked = draft.settings[key]; else input.value = draft.settings[key];
            const output = document.createElement('output');
            if (kind === 'number') { output.textContent = draft.settings[key]; titleElement.append(output); }
            input.addEventListener(kind === 'select' || kind === 'boolean' ? 'change' : 'input', () => {
                draft.settings[key] = kind === 'boolean' ? input.checked : kind === 'number' ? Number(input.value) : input.value;
                output.textContent = draft.settings[key]; changed();
            });
            label.append(titleElement, input); $('editorGrid').append(label);
        }
    }
    function savedControls() {
        $('savedList').replaceChildren();
        if (!model.saved.length) {
            const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'Здесь будут твои стили. Настрой детали и сохрани первый.'; $('savedList').append(empty);
        }
        for (const profile of model.saved) {
            const row = document.createElement('div'); row.className = 'saved-item';
            const load = document.createElement('button'), dot = document.createElement('span'), name = document.createElement('span');
            dot.className = 'saved-dot'; dot.style.background = profile.colors.focusBorder;
            name.className = 'saved-name'; name.textContent = profile.name; load.append(dot, name); load.title = 'Открыть в предпросмотре';
            load.addEventListener('click', () => choose(profile));
            const remove = document.createElement('button'); remove.className = 'saved-delete'; remove.textContent = '×'; remove.setAttribute('aria-label', 'Удалить пресет ' + profile.name);
            remove.addEventListener('click', () => send('delete', { id: profile.id })); row.append(load, remove); $('savedList').append(row);
        }
    }
    function renderFields() {
        colorControls(); editorControls(); savedControls();
        $('bgOpacity').value = draft.background.opacity; $('bgBlur').value = draft.background.blur;
        $('bgFit').value = draft.background.fit; $('bgPosition').value = draft.background.position;
        preview(); status();
    }
    $('colorTabs').addEventListener('click', event => {
        const button = event.target.closest('[data-group]'); if (!button || !draft) return;
        group = button.dataset.group; $('colorTabs').querySelectorAll('button').forEach(item => item.classList.toggle('active', item === button)); colorControls(); status();
    });
    document.querySelectorAll('.section-nav a').forEach(link => link.addEventListener('click', () => {
        document.querySelectorAll('.section-nav a').forEach(item => item.classList.toggle('active', item === link));
    }));
    $('apply').addEventListener('click', () => { clearTimeout(autoTimer); send('apply', { profile: copy(draft) }); });
    $('autoApply').addEventListener('change', () => { if (draft) changed(); });
    $('custom').addEventListener('click', () => { if (!draft) return; draft.id = 'custom'; draft.name = 'Custom'; changed(); $('presetName').focus(); });
    $('save').addEventListener('click', () => {
        const name = $('presetName').value.trim(); if (!name) { notify('Напиши название своего стиля.', true); $('presetName').focus(); return; }
        if (isInvalid()) { notify('Сначала исправь цвет.', true); return; }
        send('save', { profile: { ...copy(draft), name } });
    });
    $('import').addEventListener('click', () => send('import'));
    $('export').addEventListener('click', () => { if (!isInvalid()) send('export', { profile: copy(draft) }); });
    $('reset').addEventListener('click', () => { clearTimeout(autoTimer); $('autoApply').checked = false; persist(); send('reset'); });
    $('pickImage').addEventListener('click', () => send('image'));
    $('removeImage').addEventListener('click', () => { draft.background.image = ''; changed(); });
    for (const [id, key, numeric] of [['bgOpacity', 'opacity', true], ['bgBlur', 'blur', true], ['bgFit', 'fit', false], ['bgPosition', 'position', false]]) {
        $(id).addEventListener(numeric ? 'input' : 'change', () => { draft.background[key] = numeric ? Number($(id).value) : $(id).value; changed(); });
    }
    $('openFull').addEventListener('click', () => api.postMessage({ type: 'openFull', profile: draft && copy(draft) }));
    window.addEventListener('message', event => {
        const data = event.data; if (!data || typeof data.type !== 'string') return;
        pending = false;
        if (data.type === 'state') {
            const first = !model; model = data;
            if (first) { draft = persisted.draft?.schema === 1 ? persisted.draft : copy(model.current); palettes(); }
            if (data.selected) { draft = copy(data.selected); $('presetName').value = ''; }
            if (data.action === 'reset') draft = copy(model.current);
            if (first || data.selected || data.action === 'reset') renderFields(); else savedControls();
            $('controls').setAttribute('aria-busy', 'false');
            $('controls').removeAttribute('inert');
            if (data.action === 'saved') notify('Стиль сохранён.');
            if (data.action === 'imported') notify('Пресет импортирован. Нажми «Применить», чтобы включить.');
            if (data.action === 'reset') notify('Исходные настройки восстановлены.');
            if (data.action === 'deleted') notify('Пресет удалён.');
            persist(); status();
        } else if (data.type === 'background') { draft.background.image = data.image; changed(); }
        else if (data.type === 'error') { notify(data.message, true); status(); }
        else if (data.type === 'notice') { notify(data.message); status(); }
        else status();
    });
    api.postMessage({ type: 'ready' });
})();
